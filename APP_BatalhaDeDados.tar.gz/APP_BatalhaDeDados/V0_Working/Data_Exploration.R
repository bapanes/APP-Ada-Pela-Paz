setwd("../Dados/MeusDados")
library(dplyr)

#reading files

df_lugar_raca_branca <- read.csv("TB.csv")
df_lugar_raca_negra <- read.csv("TN.csv")
df_estado_ll <- read.csv("ELL.csv")
df_edade <- read.csv("HEG.csv")

df_edade

#plot de idade vs indice de femicidio 

ggplot(data = df_edade, aes(x = as.integer(idade), y = Feminino, color = "red")) + 
  geom_point( )+ scale_color_brewer(palette = "Dark2") +
  labs(x = "Idade", y = "Indice de Feminicidio") +
  theme(aspect.ratio = 1, legend.position = "bottom", 
        axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title = element_text(size = 15))
  theme(aspect.ratio = 1, legend.position = "bottom")

sum(df_edade$Feminino)

df_estado_ll$Sigla
head(df_lugar_raca_branca)

#branco = 0
#negro = 1

df_lugar_raca_branca <- df_lugar_raca_branca %>% mutate(cordepele = 0)
df_lugar_raca_negra <- df_lugar_raca_negra %>% mutate(cordepele = 1)

df_lugar_raca <- rbind(df_lugar_raca_branca, df_lugar_raca_negra)

df_lugar_raca

df_lugar_raca_prob <- df_lugar_raca %>% mutate(prob = X2013/sum(X2013)) 
df_lugar_raca_prob <- df_lugar_raca_prob %>% mutate(facRisco = 100.0*prob /(max(prob)))

df_lugar_raca_prob <- df_lugar_raca_prob %>% select(UF.REGIÃO, X2013, cordepele, prob, facRisco)

df_lugar_raca_prob

#Latitude e longitude

mydfLat <- rbind(df_estado_ll["Latitude"],df_estado_ll["Latitude"])
mydfLon <- rbind(df_estado_ll["Longitude"],df_estado_ll["Longitude"])

mydfLon

#todo junto

df_lugar_raca_risco <- df_lugar_raca_prob %>% mutate(lat = mydfLat$Latitude, lon = mydfLon$Longitude)

df_lugar_raca_risco

df_lugar_raca_risco <- df_lugar_raca_risco %>% select(UF.REGIÃO, lat, lon, cordepele, X2013, prob, facRisco) 

df_lugar_raca_risco

write.csv(df_lugar_raca_risco, file="df_lugar_raca_risco.csv")

####################################
# O dataframe df_lugar_raca_risco logo foi tratado em python para fazer o
# merge with the age information. This process generates as output the file
# df_estado_raca_edade.csv
####################################

df_estado_raca_edade <- read.csv("df_estado_raca_idade.csv")

colnames(df_estado_raca_edade)[colnames(df_estado_raca_edade)=="prob"] <- "prob1"
colnames(df_estado_raca_edade)[colnames(df_estado_raca_edade)=="Feminino"] <- "AbsVict"

df_estado_raca_edade_risco_fin <- df_estado_raca_edade %>% mutate(prob2 = AbsVict/100.0) %>% 
                      select(UF.REGIÃO, lat, lon, X2013, cordepele, prob1, idade, AbsVict, prob2) %>% 
                      mutate(probT = prob1*prob2) %>% mutate(facRisco = probT*100/max(probT))

str(df_estado_raca_edade_risco_fin)

df_estado_raca_edade_risco_fin

write.csv(df_estado_raca_edade_risco_fin, "df_estado_raca_idade_fin.csv")



